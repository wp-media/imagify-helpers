# Imagify | Bulk Optimize only for Super Admins (Multisite)

Bumps up the default user capacity required for bulk-optimization to Super Admin on multisite.

To be used with:
* any WordPress multisite setup where only Super Admins should have permission to handle bulk optimization

Last tested with:
* Imagify 1.8.1.x
* WordPress 4.9.x
