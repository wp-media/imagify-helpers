# Imagify | No Auto-Optimization for PDFs

Excludes PDF files from being auto-optimized once they’re uploaded.

To be used with:
* any setup where auto-optimization is enabled, but PDF files should not be auto-optimized

Last tested with:
* Imagify 1.8.1.x
* WordPress 4.9.x
