# Imagify | Change Bulk Buffer Size

Helps to avoid CPU issues during bulk optimization.

To be used with:
* any setup where optimization triggers 504 timeout errors

Last tested with:
* Imagify 1.8.1.x
* WordPress 4.9.x
